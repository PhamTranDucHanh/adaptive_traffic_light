/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/
#ifndef SCORE_LIB_FILESYSTEM_FACTORY_FILESYSTEM_FACTORY_H
#define SCORE_LIB_FILESYSTEM_FACTORY_FILESYSTEM_FACTORY_H

#include "score/filesystem/factory/i_filesystem_factory.h"

namespace score
{
namespace filesystem
{

class FilesystemFactory : public IFilesystemFactory
{
  public:
    Filesystem CreateInstance() const noexcept override;
};

}  // namespace filesystem
}  // namespace score

#endif  // SCORE_LIB_FILESYSTEM_FACTORY_FILESYSTEM_FACTORY_H
