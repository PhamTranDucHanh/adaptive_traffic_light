/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/
#include "score/concurrency/future/test_types.h"

score::concurrency::testing::CopyAndMovableType::CopyAndMovableType(int value) : value_{value} {}

int score::concurrency::testing::CopyAndMovableType::GetValue() const noexcept
{
    return value_;
}
